// Package
package org.cvtc;

// Import
import javax.swing.*;

// Test class
public abstract class ShapesTest extends Shape{

    // Main method
    public static void main(String arg[]) {

        // Create references
        Cuboid cube = new Cuboid();
        Cylinder cylinder = new Cylinder();
        Sphere sphere = new Sphere();

        // Set shape sizes
        cube.setDepth(3);
        cube.setHeight(4);
        cube.setWidth(6);

        cylinder.setHeight(3);
        cylinder.setRadius(4);

        sphere.setRadius(5);

        // Call calculation methods
        cube.surfaceArea();
        cube.volume();

        // Call render methods
        cube.render();
        cylinder.render();
        sphere.render();
    }

}
