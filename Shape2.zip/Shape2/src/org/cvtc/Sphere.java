// Package info
package org.cvtc;

import javax.swing.*;

// Class for Sphere
public class Sphere extends Shape{

    // Variables
    public float radius = 0;

    public Sphere() {

    }

    // Get and set methods
    public float getRadius() {
        return radius;
    }
    public void setRadius(float radius) {
        this.radius = radius;
    }

    // Overloaded method that also checks for negatives
    public Sphere(float radius){
        if (radius < 0){
            System.out.println("radius has to be greater than 0" + "/n/nPlease Try Again");
        }
    }



    public float surfaceArea() {
        float surfaceAreaTotal = (float) (3.14 * Math.pow(radius, 2));
        return surfaceAreaTotal;
    }


    public float volume() {
        float volumeTotal = (float) ((4/3) * Math.pow(radius, 3));
        return volumeTotal;
    }


    public void render() {
        JOptionPane.showInputDialog("Sphere Surface Area = " + surfaceArea() + "\n\nSphere Volume = " + volume());
    }
}