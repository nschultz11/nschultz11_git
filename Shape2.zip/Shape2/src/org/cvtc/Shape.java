// Packages
package org.cvtc;

// Main Class for Shape
public abstract class Shape {

    // Abstract methods
    public abstract float surfaceArea();
    public abstract float volume();
    public abstract void render();

}
