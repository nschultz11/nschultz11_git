// Package info
package org.cvtc;

import javax.swing.*;

// Class for cuboid
public class Cuboid extends Shape{

    // Variables
    private float width = 0;
    private float height = 0;
    private float depth = 0;

    public Cuboid() {

    }

    // Get and set methods
    public float getWidth() {
        return width;
    }
    public void setWidth(float width) {
        this.width = width;
    }
    public float getHeight() {
        return height;
    }
    public void setHeight(float height) {
        this.height = height;
    }
    public float getDepth() {
        return depth;
    }
    public void setDepth(float depth) {
        this.depth = depth;
    }

    // Overloaded method that also checks for negative numbers
    public Cuboid(float width, float height, float depth){
        if (width < 0 || height < 0 || depth < 0){
            JOptionPane.showInputDialog("Not Greater than 0 try again");
        }
    }



    public float surfaceArea() {
        float surfaceAreaTotal = width * height;
        return surfaceAreaTotal;
    }

    public float volume() {
        float volumeTotal = width * height * depth;
        return volumeTotal;
    }

    public void render() {
        JOptionPane.showInputDialog("Cube Surface Area = " + surfaceArea() + "\n\nCube Volume = " + volume());
    }
}