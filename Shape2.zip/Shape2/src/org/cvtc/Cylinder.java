// Package info
package org.cvtc;

import javax.swing.*;

// Class for Cylinder
public class Cylinder extends Shape{

    // Variables
    public float radius = 0;
    public float height = 0;

    public Cylinder() {

    }

    // Get and set methods
    public float getRadius() {
        return radius;
    }
    public void setRadius(float radius) {
        this.radius = radius;
    }
    public float getHeight() {
        return height;
    }
    public void setHeight(float height) {
        this.height = height;
    }

    // Overloaded method that also checks for negative numbers
    public Cylinder(float radius, float height){
        if (radius < 0 || height < 0){
            System.out.println("radius or Height has to be greater than 0" + "/n/nPlease Try Again");
        }
    }


    public float surfaceArea() {
        float surfaceAreaTotal = (float) (3.14 * Math.pow(radius, 2));
        return surfaceAreaTotal;
    }
    public float volume() {
        float volumeTotal = (float) (3.14 * Math.pow(radius, 2)) * height;
        return volumeTotal;
    }

    public void render() {
        JOptionPane.showInputDialog("Cylinder Surface Area = " + surfaceArea() + "\n\nCylinder Volume = " + volume());
    }
}
